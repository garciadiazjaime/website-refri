angular.module('mint.app.Generic', [
	'mint.app.GenericController'
	]);