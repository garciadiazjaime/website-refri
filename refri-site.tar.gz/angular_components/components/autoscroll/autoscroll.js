angular.module("mint.app.AutoScroll", [
	'mint.app.AutoScrollService'
	]);