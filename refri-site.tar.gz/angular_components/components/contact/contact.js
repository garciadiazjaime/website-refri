angular.module("mint.app.Contact", [
	'mint.app.ContactController',
	'mint.app.ContactFactory',
	'mint.app.ContactService'
	]);