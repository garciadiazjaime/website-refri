angular.module('mint.app.Constants', [])
	.constant('emailConfig', {
		// 'messageAPI': 'http://127.0.0.1:5000/',
		'messageAPI': 'http://api.mintitmedia.com/',
		'defaultEmail': 'info@refritectijuana.com',
		'website': {
			'id': 3,
			'name': 'refritec'
		}
	});