var mintApp = angular.module('mintApp', ['ngRoute', 'ui.bootstrap']);

mintApp.config(['$routeProvider', '$locationProvider', '$interpolateProvider', function($routeProvider, $locationProvider, $interpolateProvider) {
	$routeProvider.
	when('/', {
		templateUrl: '/partial/home',
		controller: 'mainCtrl'
	}).
	when('/nosotros', {
		templateUrl: '/partial/about-us',
		controller: 'mainCtrl'
	}).
	when('/soluciones', {
		templateUrl: '/partial/services',
		controller: 'mainCtrl'
	}).
	when('/soluciones/instalacion', {
		templateUrl: '/partial/services',
		controller: 'mainCtrl'
	}).
	when('/soluciones/mantenimiento', {
		templateUrl: '/partial/services',
		controller: 'mainCtrl'
	}).
	when('/soluciones/industrial', {
		templateUrl: '/partial/services',
		controller: 'mainCtrl'
	}).
	when('/productos', {
		templateUrl: '/partial/products',
		controller: 'mainCtrl'
	}).
	when('/distribucion', {
		templateUrl: '/partial/products',
		controller: 'mainCtrl'
	}).
	when('/contacto', {
		templateUrl: '/partial/contact',
		controller: 'mainCtrl'
	}).
	otherwise({
		redirectTo: '/'
	});

	$locationProvider.html5Mode({
		enabled: true,
		requireBase: false
	});
	$interpolateProvider.startSymbol('{[{').endSymbol('}]}');
}]);

mintApp.controller('gralCtrl', ['$scope', '$location', function($scope, $location) {
	$scope.mainMenu = [{
		'href': 'soluciones',
		'title': 'Soluciones'
	}, {
		'href': 'productos',
		'title': 'Productos'
	}, {
		'href': 'distribucion',
		'title': 'Distribucion'
	}, {
		'href': 'nosotros',
		'title': 'Nosotros'
	}, {
		'href': 'contacto',
		'title': 'Contacto'
	}, ];

	$scope.changeSection = function(data) {
		$scope.currentSection = data.href;
	};

	var init = function() {
		console.log('fn: gralCtrl.init');
		var bits = $location.url().split('/');
		$scope.currentSection = bits[1];
	};

	init();
}]);

mintApp.controller('mainCtrl', ['$scope', function($scope) {

	var init = function() {
		console.log('fn: mainCtrl.init');
		$scope.fieldName = [{
			'required': true
		}, {
			'min': 3
		},{
			'max': 40
		}, ];

		$scope.fieldEmail = [{
			'required': true
		},{
			'min': 3
		}, {
			'max': 40
		}, {
			'pattern': '/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}/'
		}, ];

		$scope.fieldTel = [{
			'required': true
		},{
			'min': 7
		}, {
			'max': 16
		}, ];

		$scope.fieldMessage = [{
			'required': true
		},{
			'min': 10
		}, {
			'max': 500
		}, ];
	};

	init();
}]);